from http.server import BaseHTTPRequestHandler, HTTPServer
import json

HOST, PORT = "127.0.0.1", 5000

class Handler(BaseHTTPRequestHandler):
    def send_json(self, payload):
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/balance":
            self.send_json({
                "balance": 0,
                "currency": "USD",
                "deployCost": 5.00,
                "hostBalance": 0,
                "currentSpendPerHr": 0.25,
                "environment": "LOCAL-LAB"
            })
        else:
            self.send_error(404)

    def log_message(self, fmt, *args):
        print("[API]", fmt % args)

if __name__ == "__main__":
    print(f"Mock API running at http://{HOST}:{PORT}/balance")
    HTTPServer((HOST, PORT), Handler).serve_forever()
