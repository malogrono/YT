# Burp Balance Lab

## Tujuan
Lab lokal untuk memahami response-body Match & Replace pada Burp Suite.
Tidak ada layanan cloud atau billing nyata yang digunakan.

## 1. Jalankan API
Python 3:
    python server.py

API:
    http://127.0.0.1:5000/balance

Tanpa Burp, response berisi balance 0 dan deployCost 5.00.

## 2. Buka dashboard
Buka `dashboard.html` di browser.
Jika browser memblokir file lokal, jalankan:
    python -m http.server 8000
lalu buka:
    http://127.0.0.1:8000/dashboard.html

## 3. Atur Burp
Listener:
    127.0.0.1:8080

Proxy browser ke listener tersebut.

Di Burp, Proxy -> Match and replace, buat rule Response body.
Gunakan string yang sama dengan `burp-config.json`.

Catatan: `burp-config.json` adalah template dokumentasi rule; format import
dapat berbeda antar versi Burp Suite. Jika versi Burp kamu meminta format
konfigurasi khusus, masukkan rule melalui UI Match and replace.

## 4. Hasil yang diharapkan
Server tetap mengembalikan:
    balance = 0

Tetapi response yang diterima browser setelah proxy modification dapat
menampilkan:
    balance = 500

Ini hanya perubahan pada response di jalur client. Database/server mock
tetap menyimpan nilai 0.
